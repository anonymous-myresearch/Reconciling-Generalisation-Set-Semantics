# Evaluation artefact

This package reproduces the evaluation for **Reconciling Generalisation Set Semantics in Conceptual Modelling and Semantic Web Technologies**. It contains evaluation inputs, executable checks, expected and observed results, dependency licences, and reproduction instructions.

## Reproduce

Use Python 3.10 or later, GNU Make and a Java Development Kit 17 or later with the `jdk.compiler` module. HermiT and its OWL API are bundled. Python uses only the standard library. No network connection or package installation is needed.

```sh
cd artifact
make verify-hashes
make check
make verify-hashes
```

Success means **15 distinct model/context cases, 22 regression tests and 36 HermiT checks** pass. The OWL checks comprise 30 schema/population views, two selected-type probes and four default-reading probes. Any failed comparison exits nonzero. Regression output appears in the terminal; structured semantic reports are regenerated in `results/`.

Every distributed file except the manifest itself is hashed. Generated Java classes, Python caches and `results/local-environment.json` are not distributed or hashed. Keeping the local Java version separate makes semantic result hashes portable across machines. `results/recorded-environment.json` records the original environment.

## Files

| Path | Evaluation role |
| --- | --- |
| `models/` | Fifteen FHAS input fixtures |
| `analysis/cases.json` | Scopes and explicit negative evidence |
| `analysis/expected.json` | Reference oracles |
| `analysis/transitions.json` | Transition policies and expected breaches |
| `analysis/owl-expected.json`, `defaults-expected.json` | OWL consistency oracles |
| `inputs/pem.ecore` | Structural carrier definitions used by the checker |
| `reference/check_examples.py` | Bounded interpretation and oracle comparisons |
| `tests/test_regressions.py` | Adversarial regression suite |
| `build_examples.py`, `fixture_helpers.py` | Fixture regeneration, exercised by the tests |
| `owl-reasoner/generate.py`, `inputs/` | OWL generation and recorded OWL inputs |
| `owl-reasoner/Probe.java`, `run.py` | HermiT execution and result comparisons |
| `owl-reasoner/lib/`, dependency and licence/notice files | Pinned reasoner and redistribution notices |
| `results/` | Reference/OWL reports, execution status and environment |

Expected answers are stored separately and never written by the fixture generator. This separates responsibilities without implying historical independence of oracle design. OWL generation shares the reference parser and negative-evidence calculation; HermiT supplies a separate reasoning engine.

## Interpretation needed to inspect the results

Start with `models/00_baseline.fhas` and its context and expected/recorded results. FHAS is the model notation read by the bounded parser. Product and access generalisation sets have separate identities despite sharing Account. `hasDeclaredType` records a selected classifier; inheritance supplies other positive memberships.

Cases 01 and 14 isolate abstractness without product coverage. Cases 02 and 03 encode brokerage exclusions as model declarations. Cases 04 and 05 contain the same impossible shared subclass without and with an instance. Cases 10–13 use a brokerage schema without those exclusions. Their after-states add only b1 and its explicit negative evidence. The transition check consumes the maintained-coverage setting and rejects deletion or retyping of existing records.

The adopted LML inference rule identifies an inheritance participant with stored potency zero as abstract. Potency zero alone does not determine an isolated item's status. This checker exercises that inference branch, not a complete native status-marker loader.

Omitted FHAS flags impose no corresponding requirement. Explicit false uses the assertion reading and requires actual noncoverage or overlap witnesses. The four default probes compare this with a permissive reading. An open empty description can have unnamed witnesses, whereas an exhaustively empty population cannot satisfy existential requirements. UML defaults must be resolved separately from FHAS omission. The Ecore snapshot is used for property carriers; its seed-default annotations are not executed.

Assessments use positive evidence, explicit negatives, consequences of other disjointness declarations and scoped closure. A condition is not used to prove itself. `Unknown` means insufficient evidence, while JSON `null` means not assessed because of contradictory evidence or an invalid direct selection. Case 05 retains the independently established product overlap diagnostic but withholds product coverage, access coverage and access disjointness.

Schema-only OWL views omit population closure and scoped existential declarations. Population views add assertions, justified negatives, declared closure and existential witnesses for explicit false. Named accounts are explicitly different. Queries of unsatisfiable classes or membership on inconsistent ontologies are skipped and recorded as null. The selection probes have identical logical memberships and different selected-type annotations.

## Execution boundaries

The executed routes are the bounded Python reference analysis, its regressions and generated OWL/HermiT experiments. The checker does not load models into EMF or establish complete PAMoLa conformance. Native PAMoLa, the actual model2owl generator, SHACL validation and OCL-engine execution remain unexecuted, as recorded in `results/integration-status.json`.
