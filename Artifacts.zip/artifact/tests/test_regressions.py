"""Adversarial regressions, separate from fixture and oracle generation."""
import sys,json,hashlib,subprocess,unittest
from copy import deepcopy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'reference'))
from check_examples import parse,check_structure,analyse,schema,verify_transition,schema_unsatisfiable
CASES=json.loads((ROOT/'analysis/cases.json').read_text())['cases']
def load(case):return parse((ROOT/'models'/f'{case}.fhas').read_text())[1]
class Regressions(unittest.TestCase):
 def test_abstract_is_inferred(self):
  self.assertEqual(schema(load('00_baseline'))[3],{'O1.Account'})
 def test_potency_zero_alone_is_not_abstract(self):
  i=load('00_baseline');i['O1.SavingsAccount'].props['hasPotency']=0
  # A separate isolated zero-potency classifier must not be silently assigned Abstract.
  from check_examples import Node
  n=Node('EN',{'hasName':'Isolated','hasPotency':0},[],'O1.Isolated');i['O1.Isolated']=n;i['O1'].wards.append(n)
  self.assertNotIn('O1.Isolated',schema(i)[3])
 def test_omitted_flags_preserved(self):
  i=load('00_baseline');c=i['O1.DualAccessSpecialisesCheckingAccount']
  self.assertNotIn('isComplete',c.props);self.assertNotIn('isDisjoint',c.props)
 def test_false_on_single_branch_is_impossible(self):
  i=load('00_baseline');cat='O1.DualAccessSpecialisesCheckingAccount';i[cat].props['isDisjoint']=False
  self.assertIn([cat,'isDisjoint'],analyse(i,CASES['00_baseline'])['declaration_failures'])
 def test_false_is_distinct_from_omission(self):
  i=load('08_empty_population');a=analyse(i,CASES['08_empty_population'])
  self.assertIn(['O1.AccountByAccessKind','isDisjoint'],a['declaration_failures'])
  del i['O1.AccountByAccessKind'].props['isDisjoint']
  self.assertNotIn(['O1.AccountByAccessKind','isDisjoint'],analyse(i,CASES['08_empty_population'])['declaration_failures'])
 def test_bad_boolean_rejected(self):
  i=load('00_baseline');i['O1.AccountByProductKind'].props['isComplete']='false'
  with self.assertRaises(AssertionError):check_structure(i)
 def test_bad_potency_rejected(self):
  for value in [-1,True,'1']:
   i=load('00_baseline');i['O1.Account'].props['hasPotency']=value
   with self.assertRaises(AssertionError):check_structure(i)
 def test_empty_population_is_vacuous(self):
  self.assertEqual(set(analyse(load('08_empty_population'),CASES['08_empty_population'])['current'].values()),{'Yes'})
 def test_empty_branch_does_not_break_cover(self):
  self.assertEqual(analyse(load('07_only_checking_populated'),CASES['07_only_checking_populated'])['current']['productCoverage'],'Yes')
 def test_exclusions_establish_gap_without_closure(self):
  c=CASES['02_uncovered_account'];self.assertFalse(c['memberships_closed']);self.assertFalse(c['population_closed'])
  self.assertIn('b1',analyse(load('02_uncovered_account'),c)['coverage_witnesses']['product'])
 def test_removing_exclusions_removes_negative_evidence(self):
  i=load('02_uncovered_account');i['O1'].wards=[n for n in i['O1'].wards if 'Exclusion' not in n.path]
  self.assertEqual(analyse(i,CASES['02_uncovered_account'])['current']['productCoverage'],'Unknown')
 def test_partial_overlap_needs_no_closure(self):
  a=analyse(load('09_partial_population'),CASES['09_partial_population'])
  self.assertEqual(a['current']['accessDisjointness'],'No');self.assertEqual(a['current']['productCoverage'],'Unknown')
 def test_brokerage_exclusion_schema_is_unsatisfiable(self):
  self.assertEqual(schema_unsatisfiable(load('02_uncovered_account')),['BrokerageAccount'])
 def test_transition_schema_is_satisfiable(self):
  self.assertEqual(schema_unsatisfiable(load('10_invariant_before')),[])
 def test_policy_field_is_consumed(self):
  b=load('10_invariant_before');a=load('11_invariant_after');r=analyse(a,CASES['11_invariant_after'])
  self.assertEqual(verify_transition(b,a,{'maintain_coverage':True},r),['AccountByProductKind'])
  self.assertEqual(verify_transition(b,a,{'maintain_coverage':False},r),[])
 def test_retyping_old_account_is_rejected(self):
  b=load('10_invariant_before');a=load('11_invariant_after');a['O2.c1'].props['hasDeclaredType']='O1.SavingsAccount'
  with self.assertRaises(AssertionError):verify_transition(b,a,{'maintain_coverage':True},analyse(a,CASES['11_invariant_after']))
 def test_deleting_old_account_is_rejected(self):
  b=load('10_invariant_before');a=load('11_invariant_after');del a['O2.s1']
  with self.assertRaises(AssertionError):verify_transition(b,a,{'maintain_coverage':True},{})
 def test_fixture_generator_does_not_write_oracles(self):
  p=ROOT/'analysis/expected.json';before=p.read_bytes();models={p.name:p.read_bytes() for p in (ROOT/'models').glob('*.fhas')}
  subprocess.run([sys.executable,str(ROOT/'build_examples.py')],check=True)
  self.assertEqual(p.read_bytes(),before);self.assertEqual(models,{p.name:p.read_bytes() for p in (ROOT/'models').glob('*.fhas')})
 def test_abstractness_pair_has_no_cover_requirement(self):
  for name in ['01_abstract_direct_attempt','14_abstract_control']:
   self.assertNotIn('isComplete',load(name)['O1.AccountByProductKind'].props)
  self.assertEqual(analyse(load('14_abstract_control'),CASES['14_abstract_control'])['type_findings'],[])
  self.assertEqual(analyse(load('01_abstract_direct_attempt'),CASES['01_abstract_direct_attempt'])['type_findings'],[['c1','Account','declaredTypeAbstract']])
 def test_conflicting_hybrid_withholds_unrelated_assessments(self):
  for population_closed in [False,True]:
   for memberships_closed in [False,True]:
    with self.subTest(population_closed=population_closed,memberships_closed=memberships_closed):
     c={**CASES['05_populated_shared_specialisation'],'population_closed':population_closed,'memberships_closed':memberships_closed}
     r=analyse(load('05_populated_shared_specialisation'),c)
     self.assertEqual(r['current'],{'productCoverage':None,'productDisjointness':'No','accessCoverage':None,'accessDisjointness':None})
     self.assertEqual(r['evidence_conflicts'],[['x1','O1.CheckingAccount'],['x1','O1.HybridAccount'],['x1','O1.SavingsAccount']])
     self.assertEqual(r['assessments_not_performed'],['accessCoverage','accessDisjointness','productCoverage'])
     self.assertEqual(r['declaration_failures'],[['O1.AccountByProductKind','isDisjoint']])
 def test_explicit_conflict_is_not_unknown_or_a_success(self):
  c={**CASES['00_baseline'],'negative_memberships':[['c1','CheckingAccount']]}
  r=analyse(load('00_baseline'),c)
  self.assertTrue(r['evidence_conflicts'])
  self.assertEqual(set(r['current'].values()),{None})
  self.assertEqual(len(r['assessments_not_performed']),4)
  self.assertEqual(r['declaration_failures'],[])
  self.assertEqual(r['declarations_undetermined'],[])
 def test_withdrawing_conflict_restores_assessments(self):
  i=load('05_populated_shared_specialisation');i['O1.AccountByProductKind'].props['isDisjoint']=False
  r=analyse(i,CASES['05_populated_shared_specialisation'])
  self.assertEqual(r['evidence_conflicts'],[])
  self.assertEqual(r['assessments_not_performed'],[])
  self.assertEqual(r['current'],{'productCoverage':'Yes','productDisjointness':'No','accessCoverage':'No','accessDisjointness':'No'})
if __name__=='__main__':unittest.main(verbosity=2)
