"""Bounded reference checker. Not a native PAMoLa runtime or a full HUTN parser.

Reads the supplied FHAS subset, checks its property carriers against the PEM,
resolves local references, computes finite inheritance membership, and compares
separately stored oracle rows. It does not execute native LML/TRD rules.
"""
from dataclasses import dataclass, field
from pathlib import Path
import json
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TOKEN = re.compile(r'\s+|//[^\n]*|"(?:\\.|[^"\\])*"|[{},]|[^\s{},]+')

@dataclass
class Node:
    badge: str
    props: dict = field(default_factory=dict)
    wards: list = field(default_factory=list)
    path: str = ''

def parse(text):
    tokens = [m.group() for m in TOKEN.finditer(text)
              if not m.group().isspace() and not m.group().startswith('//')]
    pos = 0
    def take(expected=None):
        nonlocal pos
        assert pos < len(tokens), 'Unexpected end of FHAS'
        token = tokens[pos]; pos += 1
        assert expected is None or token == expected, (expected, token)
        return token
    def record():
        n = Node(take()); take('{')
        while tokens[pos] != '}':
            if pos + 1 < len(tokens) and tokens[pos + 1] == '{':
                n.wards.append(record())
            else:
                key = take(); value = take()
                assert key not in n.props, ('Duplicate feature', key)
                n.props[key] = json.loads(value) if value.startswith('"') else (
                    True if value == 'true' else False if value == 'false' else
                    int(value) if re.fullmatch(r'-?\d+', value) else value)
            if tokens[pos] == ',': take(',')
            else: assert tokens[pos] == '}', tokens[pos]
        take('}')
        return n
    root = record()
    assert pos == len(tokens), 'Trailing tokens'
    index = {}
    pids = set()
    def register(n, prefix=None):
        n.path = '' if prefix is None else ((prefix + '.') if prefix else '') + n.props['hasName']
        assert n.path not in index, ('Duplicate local path', n.path)
        assert n.props['hasPID'] not in pids, ('Duplicate PID', n.path)
        pids.add(n.props['hasPID']); index[n.path] = n
        for w in n.wards:
            register(w, n.path)
    register(root)
    return root, index

def pem_contract():
    p = ET.parse(ROOT / 'inputs' / 'pem.ecore').getroot()
    xsi = '{http://www.w3.org/2001/XMLSchema-instance}type'
    classes = {c.get('name'): c for c in p.findall('eClassifiers')
               if c.get(xsi) == 'ecore:EClass'}
    badges = {}
    for name, c in classes.items():
        for d in c.findall('./eAnnotations/details'):
            if d.get('key') == 'badge': badges[d.get('value')] = name
    def features(name):
        c = classes[name]
        result = {}
        for parent in c.get('eSuperTypes', '').split(): result.update(features(parent[3:]))
        result.update({f.get('name'): f for f in c.findall('eStructuralFeatures')})
        return result
    return classes, badges, features

def check_structure(index):
    classes, badges, features = pem_contract()
    refs = 0
    for path, n in index.items():
        assert n.badge in badges, ('Unknown badge', n.badge)
        cls = badges[n.badge]; available = features(cls)
        for key in ['isComplete','isDisjoint','isGeneralisation']:
            if key in n.props: assert type(n.props[key]) is bool, ('Not Boolean', path, key)
        if 'hasPotency' in n.props:
            assert type(n.props['hasPotency']) is int and n.props['hasPotency'] >= 0, ('Invalid potency', path)

        for key, value in n.props.items():
            assert key in available, ('Feature absent from PEM', path, key)
            f = available[key]
            if f.get('eType') == '#//Clabject':
                assert value in index, ('Unresolved reference', path, key, value)
                assert index[value].badge in ('EN', 'RE'), ('Not a clabject', value)
                refs += 1
            elif f.get('eType') == '#//Ordium':
                assert value in index, ('Unresolved reference', path, key, value)
                refs += 1
            # Scalar values in DataValue-valued slots are type-directed HUTN sugar.
            # Their materialisation as PEM DataValue objects is not tested here.
    return refs

def schema(index):
    names={n.path for n in index['O1'].wards if n.badge=='EN'}
    groups={};parents={x:set() for x in names}
    for cat in index['O1'].wards:
        if cat.badge!='CA':continue
        ends=[w for w in cat.wards if w.badge=='IC']
        general=[w.props['hasRelatum'] for w in ends if w.props.get('isGeneralisation') is True]
        special=[w.props['hasRelatum'] for w in ends if w.props.get('isGeneralisation') is not True]
        assert len(general)==1 and special and len(set(special))==len(special),('Malformed set',cat.path)
        groups[cat.path]=(general[0],special)
        for child in special:parents[child].add(general[0])
    ancestors={x:{x} for x in names}
    while True:
        expanded={x:ancestors[x]|set().union(*(ancestors[p] for p in parents[x])) for x in names}
        if expanded==ancestors:break
        ancestors=expanded
    assert all(x not in set().union(*(ancestors[p] for p in parents[x])) for x in names),'Inheritance cycle'
    participants=set().union(*(set([g]+ss) for g,ss in groups.values()))
    abstract={x for x in participants if index[x].props.get('hasPotency')==0}
    return names,groups,ancestors,abstract

def schema_unsatisfiable(index):
    """Exact propositional schema check for this named-class fragment, independent of population closure."""
    names,groups,ancestors,_=schema(index);ordered=sorted(names);possible=set()
    for bits in range(1<<len(ordered)):
        state={n for i,n in enumerate(ordered) if bits&(1<<i)}
        if any(not ancestors[x]<=state for x in state):continue
        valid=True
        for cat,(general,special) in groups.items():
            if index[cat].props.get('isComplete') is True and general in state and not state.intersection(special):valid=False
            if index[cat].props.get('isDisjoint') is True and len(state.intersection(special))>1:valid=False
        if valid:possible.update(state)
    return sorted(x[3:] for x in names-possible)

def negative_evidence(index,contract,positives,excluded_disjoint_set=None):
    names,groups,ancestors,_=schema(index)
    negative={x:set() for x in positives}
    for x,c in contract.get('negative_memberships',[]):
        assert x in negative and 'O1.'+c in names,('Bad explicit negative',x,c)
        negative[x].add('O1.'+c)
    if contract['memberships_closed']:
        for x,ps in positives.items():negative[x].update(names-ps)
    for cat,(_,special) in groups.items():
        if cat==excluded_disjoint_set or index[cat].props.get('isDisjoint') is not True:continue
        for x,ps in positives.items():
            for s in set(special)&ps:negative[x].update(t for t in special if t!=s)
    for x,ns in negative.items():
        negative[x]|={s for s in names if ancestors[s]&ns}
    return negative

def analyse(index,contract):
    names,groups,ancestors,abstract=schema(index)
    structural=[]
    for cat,(_,special) in groups.items():
        if index[cat].props.get('isDisjoint') is not True:continue
        for x in sorted(names):
            branches=sorted(set(special)&ancestors[x])
            for i,left in enumerate(branches):
                for right in branches[i+1:]:structural.append([cat[3:],left[3:],right[3:],x[3:]])
    type_findings=[]
    for x in index[contract['population_root']].wards:
        typ=x.props.get('hasDeclaredType');assert typ in names,('Unresolved selected type',x.path)
        if typ in abstract:type_findings.append([x.props['hasName'],typ[3:],'declaredTypeAbstract'])
        elif index[typ].props.get('hasPotency',0)<=x.props.get('hasPotency',0):
            type_findings.append([x.props['hasName'],typ[3:],'potencyEligibility'])
    result=dict(current=None,schema_findings=structural,type_findings=type_findings,
        abstract_classifiers=sorted(x[3:] for x in abstract),
        schema_unsatisfiable_classes=schema_unsatisfiable(index),
        memberships={},negative_memberships={},coverage_witnesses={},overlap_witnesses={},
        declaration_failures=[],declarations_undetermined=[],
        evidence_conflicts=[],assessments_not_performed=[],
        interpretation='authored candidate diagnostic view' if structural or type_findings else 'bounded reference interpretation')
    if type_findings:return result
    positives={x.props['hasName']:set(ancestors[x.props['hasDeclaredType']]) for x in index[contract['population_root']].wards}
    def conflicts(negative):
        return sorted([x,c] for x,ps in positives.items() for c in ps&negative[x])
    full_negative=negative_evidence(index,contract,positives)
    full_conflicts=conflicts(full_negative)
    if full_conflicts:result['interpretation']='authored candidate diagnostic view'
    current={};cw={};ow={};not_assessed=[]
    for prefix,cat in [('product','O1.AccountByProductKind'),('access','O1.AccountByAccessKind')]:
        general,special=groups[cat];accounts={x for x,ps in positives.items() if general in ps}
        ns=full_negative
        gaps=sorted(x for x in accounts if set(special)<=ns[x] and not positives[x]&set(special))
        overlaps=sorted(x for x in accounts if len(positives[x]&set(special))>1)
        if full_conflicts:
            current[prefix+'Coverage']=None
            not_assessed.append(prefix+'Coverage')
        else:
            current[prefix+'Coverage']='No' if gaps else 'Yes' if contract['population_closed'] and all(positives[x]&set(special) for x in accounts) else 'Unknown'
        independent_ns=negative_evidence(index,contract,positives,cat)
        pairs=[(s,t) for i,s in enumerate(special) for t in special[i+1:]]
        no_overlap=all(s in independent_ns[x] or t in independent_ns[x] for x in accounts for s,t in pairs)
        if conflicts(independent_ns):
            current[prefix+'Disjointness']=None
            not_assessed.append(prefix+'Disjointness')
        else:
            current[prefix+'Disjointness']='No' if overlaps else 'Yes' if contract['population_closed'] and no_overlap else 'Unknown'
        cw[prefix]=gaps;ow[prefix]=overlaps
    failures=[];unknown=[]
    for prefix,cat in [('product','O1.AccountByProductKind'),('access','O1.AccountByAccessKind')]:
        for prop,suffix in [('isComplete','Coverage'),('isDisjoint','Disjointness')]:
            if prop not in index[cat].props:continue
            value=current[prefix+suffix]
            if value is None:continue
            if value=='Unknown':unknown.append([cat,prop])
            elif (value=='Yes')!=index[cat].props[prop]:failures.append([cat,prop])
    for cat,(_,special) in groups.items():
        if len(special)==1 and index[cat].props.get('isDisjoint') is False:
            failures.append([cat,'isDisjoint'])
    result.update(current=current,memberships={x:sorted(v) for x,v in positives.items()},
        negative_memberships={x:sorted(v) for x,v in full_negative.items()},
        coverage_witnesses=cw,overlap_witnesses=ow,declaration_failures=failures,declarations_undetermined=unknown,
        evidence_conflicts=full_conflicts,assessments_not_performed=sorted(not_assessed))
    return result

def verify_transition(before,after,policy,after_result):
    """Every pre-existing record must be unchanged, including membership-relevant data."""
    def record(n):return n.badge,n.props,tuple(w.path for w in n.wards)
    assert set(before)<=set(after),'Existing record deleted'
    for p,n in before.items():
        if p=='O2':
            assert n.badge==after[p].badge and n.props==after[p].props,'Population container changed'
        else:assert record(n)==record(after[p]),('Existing record changed',p)
    assert set(after)-set(before)=={'O2.b1'},'Only b1 may be added'
    return ['AccountByProductKind'] if policy['maintain_coverage'] and after_result['current']['productCoverage']=='No' else []

def main():
    cases=json.loads((ROOT/'analysis/cases.json').read_text())['cases']
    expected=json.loads((ROOT/'analysis/expected.json').read_text())['cases']
    outputs={};indices={};signatures=set()
    for case,contract in cases.items():
        raw=(ROOT/'models'/f'{case}.fhas').read_text();_,index=parse(raw);check_structure(index)
        actual=analyse(index,contract);oracle=expected[case]
        for key,out in [('expected_current','current'),('expected_schema_findings','schema_findings'),('expected_type_findings','type_findings'),('expected_declaration_failures','declaration_failures'),('expected_declarations_undetermined','declarations_undetermined'),('schema_unsatisfiable_classes','schema_unsatisfiable_classes')]:
            assert actual[out]==oracle[key],(case,out,actual[out],oracle[key])
        for key in ['evidence_conflicts','assessments_not_performed']:
            assert actual[key]==oracle.get(key,[]),(case,key,actual[key],oracle.get(key,[]))
        signatures.add((raw,json.dumps(contract,sort_keys=True)));outputs[case]=actual;indices[case]=index
    transitions=[]
    for p in json.loads((ROOT/'analysis/transitions.json').read_text())['transitions']:
        breaches=verify_transition(indices[p['before']],indices[p['after']],p,outputs[p['after']]);assert breaches==p['expected_breaches']
        transitions.append({**p,'observed_breaches':breaches})
    assert len(signatures)==len(cases),'Duplicate input/context case'
    result=dict(status='passed',implementation='bounded reference checker; not native PAMoLa',cases_checked=len(cases),distinct_input_contexts=len(signatures),transitions=transitions,cases=outputs)
    (ROOT/'results/reference-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
