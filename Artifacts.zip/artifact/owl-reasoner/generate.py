"""Project schema and scoped population separately. No OWL tool is invoked here."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'reference'))
from check_examples import parse,schema,negative_evidence
OUT=ROOT/'owl-reasoner/inputs'
def cls(s):return ':'+s.removeprefix('O1.')
def union(ss):return cls(ss[0]) if len(ss)==1 else 'ObjectUnionOf('+' '.join(map(cls,ss))+')'
def write(name,axioms):
 OUT.mkdir(exist_ok=True);(OUT/name).write_text('Prefix(:=<https://example.org/account#>)\nPrefix(owl:=<http://www.w3.org/2002/07/owl#>)\nOntology(\n'+'\n'.join(axioms)+'\n)\n')
def generate():
 cases=json.loads((ROOT/'analysis/cases.json').read_text())['cases']
 for name,context in cases.items():
  _,idx=parse((ROOT/'models'/f'{name}.fhas').read_text());names,groups,ancestors,abstract=schema(idx)
  axioms=['Declaration(Class('+cls(c)+'))' for c in sorted(names)]
  for g,(a,ss) in groups.items():
   axioms += ['SubClassOf('+cls(s)+' '+cls(a)+')' for s in ss]
   if idx[g].props.get('isComplete') is True:axioms.append('SubClassOf('+cls(a)+' '+union(ss)+')')
   if idx[g].props.get('isDisjoint') is True and len(ss)>1:axioms.append('DisjointClasses('+' '.join(map(cls,ss))+')')
  write(name+'-schema.ofn',axioms)
  pop=list(axioms)+['Declaration(AnnotationProperty(:selectedType))']
  positives={n.props['hasName']:set(ancestors[n.props['hasDeclaredType']]) for n in idx['O2'].wards}
  for n in idx['O2'].wards:
   x=n.props['hasName'];t=n.props['hasDeclaredType']
   pop += ['Declaration(NamedIndividual(:'+x+'))','ClassAssertion('+cls(t)+' :'+x+')','AnnotationAssertion(:selectedType :'+x+' '+cls(t)+')']
  negative=negative_evidence(idx,context,positives)
  for x,cs in sorted(negative.items()):
   for c in sorted(cs):pop.append('ClassAssertion(ObjectComplementOf('+cls(c)+') :'+x+')')
  if context['population_closed']:
   values='ObjectOneOf('+' '.join(':'+x for x in sorted(positives))+')' if positives else 'owl:Nothing'
   pop.append('SubClassOf(:Account '+values+')')
  if len(positives)>1:pop.append('DifferentIndividuals('+' '.join(':'+x for x in sorted(positives))+')')
  for gi,(g,(a,ss)) in enumerate(groups.items()):
   if idx[g].props.get('isComplete') is False:
    pop.append('ClassAssertion(ObjectIntersectionOf('+cls(a)+' ObjectComplementOf('+union(ss)+')) _:cover'+str(gi)+')')
   if idx[g].props.get('isDisjoint') is False:
    pairs=['ObjectIntersectionOf('+cls(s)+' '+cls(t)+')' for i,s in enumerate(ss) for t in ss[i+1:]]
    expr=pairs[0] if len(pairs)==1 else 'ObjectUnionOf('+' '.join(pairs)+')' if pairs else 'owl:Nothing'
    pop.append('ClassAssertion('+expr+' _:overlap'+str(gi)+')')
  write(name+'-population.ofn',pop)
 # Extensional projection collision: same logical axioms, different authored selection metadata.
 for selected in ['CheckingAccount','Account']:
  write('selection-'+selected+'.ofn',['Declaration(Class(:Account))','Declaration(Class(:CheckingAccount))','Declaration(AnnotationProperty(:selectedType))','SubClassOf(:CheckingAccount :Account)','ClassAssertion(:CheckingAccount :c1)','ClassAssertion(:Account :c1)','AnnotationAssertion(:selectedType :c1 :'+selected+')'])
 # Contrast the assertion and permissive readings of default-false set flags.
 # There are no named account records in any of these four inputs.
 base=['Declaration(Class(:Account))','Declaration(Class(:CheckingAccount))','Declaration(Class(:SavingsAccount))','SubClassOf(:CheckingAccount :Account)','SubClassOf(:SavingsAccount :Account)']
 for reading in ['assertion','permission']:
  for scope in ['open','closed-empty']:
   axioms=list(base)
   if reading=='assertion':
    axioms += ['ClassAssertion(ObjectIntersectionOf(:Account ObjectComplementOf(ObjectUnionOf(:CheckingAccount :SavingsAccount))) _:uncovered)','ClassAssertion(ObjectIntersectionOf(:CheckingAccount :SavingsAccount) _:shared)']
   if scope=='closed-empty':axioms.append('SubClassOf(:Account owl:Nothing)')
   write('defaults-'+reading+'-'+scope+'.ofn',axioms)
if __name__=='__main__':generate()
