from pathlib import Path
import json,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'owl-reasoner'
sys.path.insert(0,str(HERE));from generate import generate
def main():
 generate();jar=HERE/'lib/HermiT.jar';meta=json.loads((HERE/'DEPENDENCIES.json').read_text())
 assert hashlib.sha256(jar.read_bytes()).hexdigest()==meta['HermiT']['sha256']
 build=HERE/'build';build.mkdir(exist_ok=True)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',str(jar),'-d',str(build),str(HERE/'Probe.java')],check=True)
 expected_schema=json.loads((ROOT/'analysis/expected.json').read_text())['cases']
 expected_population=json.loads((ROOT/'analysis/owl-expected.json').read_text())
 expected_defaults=json.loads((ROOT/'analysis/defaults-expected.json').read_text())
 paths=sorted((HERE/'inputs').glob('*.ofn'))
 r=subprocess.run(['java','-cp',str(jar)+':'+str(build),'Probe',*map(str,paths)],capture_output=True,text=True,timeout=120)
 if r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
 rows=[json.loads(line) for line in r.stdout.splitlines() if line.startswith('{')]
 assert len(rows)==len(paths)
 for path,row in zip(paths,rows):
  if '-schema.ofn' in path.name:
   name=path.name.removesuffix('-schema.ofn');assert row['consistent'];assert row['unsatisfiable_classes']==expected_schema[name]['schema_unsatisfiable_classes'],row
  elif '-population.ofn' in path.name:
   name=path.name.removesuffix('-population.ofn');assert row['consistent']==expected_population[name],row
  elif path.name in expected_defaults:
   assert row['consistent']==expected_defaults[path.name],row
 assert {row['file'] for row in rows if row['file'].startswith('defaults-')}==set(expected_defaults)
 left,right=[r for r in rows if r['file'].startswith('selection-')]
 assert left['consistent'] and right['consistent'] and left['c1_types']==right['c1_types']==['Account','CheckingAccount']
 assert left['c1_most_specific_types']==right['c1_most_specific_types']==['CheckingAccount']
 # Environment metadata is deliberately separate from reproducible semantic results.
 # This local file is regenerated and excluded from the distribution's hash manifest.
 java_version=subprocess.run(['java','-version'],capture_output=True,text=True,check=True).stderr.splitlines()[0]
 (ROOT/'results/local-environment.json').write_text(json.dumps({'java':java_version},indent=2)+'\n')
 report={'status':'passed','reasoner':meta['HermiT'],'ontologies_checked':len(rows),'rows':rows}
 (ROOT/'results/defaults-results.json').write_text(json.dumps({'status':'passed','named_source_accounts':0,'rows':[row for row in rows if row['file'].startswith('defaults-')]},indent=2)+'\n')
 (ROOT/'results/owl-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
if __name__=='__main__':main()
