import java.io.File;
import java.util.*;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.*;
import org.semanticweb.owlapi.profiles.*;
import org.semanticweb.HermiT.Reasoner.ReasonerFactory;
public class Probe {
 static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
 static String arr(Collection<String> xs){StringJoiner j=new StringJoiner(",","[","]");for(String s:xs)j.add(quote(s));return j.toString();}
 public static void probe(String path)throws Exception{
  OWLOntologyManager m=OWLManager.createOWLOntologyManager();OWLOntology o=m.loadOntologyFromOntologyDocument(new File(path));
  OWLProfileReport profile=new OWL2DLProfile().checkOntology(o);
  if(!profile.isInProfile())throw new IllegalArgumentException("Not OWL 2 DL: "+profile.getViolations());
  OWLReasoner r=new ReasonerFactory().createReasoner(o);boolean consistent=r.isConsistent();
  SortedSet<String> unsat=new TreeSet<>(),types=new TreeSet<>(),direct=new TreeSet<>();
  if(consistent){for(OWLClass c:r.getUnsatisfiableClasses().getEntitiesMinusBottom())unsat.add(c.getIRI().getFragment());
   for(OWLClass c:r.getTypes(m.getOWLDataFactory().getOWLNamedIndividual(IRI.create("https://example.org/account#c1")),false).getFlattened())if(!c.isOWLThing())types.add(c.getIRI().getFragment());
   for(OWLClass c:r.getTypes(m.getOWLDataFactory().getOWLNamedIndividual(IRI.create("https://example.org/account#c1")),true).getFlattened())if(!c.isOWLThing())direct.add(c.getIRI().getFragment());}
  System.out.println("{\"file\":"+quote(new File(path).getName())+",\"status\":\"executed\",\"owl2dl\":true,\"consistent\":"+consistent+",\"unsatisfiable_classes\":"+(consistent?arr(unsat):"null")+",\"c1_types\":"+(consistent?arr(types):"null")+",\"c1_most_specific_types\":"+(consistent?arr(direct):"null")+"}");r.dispose();
 }
 public static void main(String[] args)throws Exception{for(String path:args)probe(path);}
}
